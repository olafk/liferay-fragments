fragmentElement.onmouseover=function(){
  fragmentElement.classList.add("hidden");
	setTimeout(function(){
        fragmentElement.classList.remove("hidden");
  	}, 5000);
}