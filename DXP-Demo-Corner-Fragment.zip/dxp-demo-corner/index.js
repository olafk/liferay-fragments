const editMode = document.body.classList.contains('has-edit-mode-menu');
var isHoveringSince = 0;
// To preview edit mode when editing the fragment: Change condition to 
// !editMode (but remember to change back before publishing)
if (editMode) {
	// In edit mode: Make sure the fragment doesn't disappear immediately
	// as authors might want to change the content. In order to do so, a 
	// grace period is honored, in which the text can be selected, and the
	// mouse positioned elsewhere. If the fragment is blocking access to 
	// anything, it will eventually disappear on hovering long enough.
  fragmentElement.onmouseover=function() {
//    console.log("onmouseover " + isHoveringSince + " " + Date.now());
		fragmentElement.classList.add("grace-period");
    if(isHoveringSince==0) { isHoveringSince = Date.now(); }
    if(isHoveringSince > 0 && (Date.now() - isHoveringSince) > 2000) {
      fragmentElement.classList.add("hidden");
      setTimeout(function() {
        fragmentElement.classList.remove("hidden");
      }, 10000);
    };
  };
  fragmentElement.onmouseleave=function() {
 //   console.log("onmouseleave");
		fragmentElement.classList.remove("grade-period");
    isHoveringSince=0; 
  }; 
} else {
	// In view mode: Disappear immediately on hover, in order to 
	// free up potential UI elements that might be blocked by it. This
	// way we don't need to deal with z-index
  fragmentElement.onmouseover=function() {
    fragmentElement.classList.add("hidden");
	  setTimeout(function() {
        fragmentElement.classList.remove("hidden");
  	}, 5000);
	}
}